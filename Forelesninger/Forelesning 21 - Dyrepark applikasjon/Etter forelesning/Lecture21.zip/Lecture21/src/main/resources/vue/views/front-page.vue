<template id="front-page">
  <h1 class="title">Welcome to the zoo register!</h1>
</template>
<script>
app.component("front-page", {
  template: "#front-page",
});
</script>
<style>
.title {
  color: maroon;
}
</style>